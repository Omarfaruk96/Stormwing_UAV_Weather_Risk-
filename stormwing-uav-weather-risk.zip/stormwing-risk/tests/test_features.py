import pandas as pd
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.features.feature_engineering import build_features, load_config, categorize_risk


def _sample_df():
    return pd.DataFrame([
        # calm, clear
        {"station_id": "TEST", "timestamp_utc": "2024-01-01T00:00:00Z", "wind_dir_deg": 0,
         "wind_speed_kt": 5, "gust_kt": 6, "temp_c": 20, "dewpoint_c": 10,
         "visibility_sm": 10, "ceiling_ft": 20000, "precip_type": "none"},
        # severe storm: high wind/gust, icing temp, low vis/ceiling
        {"station_id": "TEST", "timestamp_utc": "2024-01-01T01:00:00Z", "wind_dir_deg": 90,
         "wind_speed_kt": 40, "gust_kt": 55, "temp_c": 0, "dewpoint_c": -0.5,
         "visibility_sm": 0.5, "ceiling_ft": 200, "precip_type": "freezing_rain"},
    ])


def test_calm_conditions_are_low_risk():
    cfg = load_config("config/config.yaml")
    feats = build_features(_sample_df(), cfg)
    calm_row = feats.iloc[0]
    assert calm_row["risk_category"] == "LOW"
    assert calm_row["icing_flag"] == 0
    assert calm_row["wind_exceed_flag"] == 0


def test_severe_storm_is_high_risk():
    cfg = load_config("config/config.yaml")
    feats = build_features(_sample_df(), cfg)
    storm_row = feats.iloc[1]
    assert storm_row["risk_category"] in ("HIGH", "NO_FLY")
    assert storm_row["icing_flag"] == 1
    assert storm_row["wind_exceed_flag"] == 1
    assert storm_row["gust_exceed_flag"] == 1
    assert storm_row["low_visibility_flag"] == 1
    assert storm_row["low_ceiling_flag"] == 1


def test_risk_score_monotonic_with_wind():
    cfg = load_config("config/config.yaml")
    df = _sample_df()
    feats = build_features(df, cfg)
    assert feats.iloc[1]["risk_score"] > feats.iloc[0]["risk_score"]


def test_categorize_risk_bins():
    bands = {"low_max": 25, "moderate_max": 55, "high_max": 80}
    cats = categorize_risk(pd.Series([0, 25, 26, 55, 56, 80, 81, 100]), bands)
    assert list(cats) == ["LOW", "LOW", "MODERATE", "MODERATE", "HIGH", "HIGH", "NO_FLY", "NO_FLY"]
