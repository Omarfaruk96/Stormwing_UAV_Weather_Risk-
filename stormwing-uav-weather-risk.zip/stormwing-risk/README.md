# StormWing — UAV Flight-Risk Prediction from Aviation Weather

Predicts a continuous **flight risk score (0–100)** and a **risk category**
(LOW / MODERATE / HIGH / NO-FLY) for a given airport/location, altitude band,
and time window, using METAR/TAF-style observations: wind speed, gust,
crosswind component, temperature/dewpoint spread (icing proxy), visibility,
ceiling, and precipitation type.

Built to slot into a UAV ground-control / mission-planning pipeline as a
pre-flight and in-flight go/no-go advisory signal — **not** a certified
airworthiness or ATC decision system (see "Important Limitations" below).

## What's in this repo

```
stormwing-risk/
├── config/config.yaml            # thresholds, model + data settings
├── data/
│   ├── raw/                      # drop real METAR/TAF CSV/JSON here
│   └── processed/                # generated feature tables land here
├── src/
│   ├── data/
│   │   ├── fetch_metar.py        # pulls live METAR/TAF from aviationweather.gov
│   │   └── synthetic_generator.py# generates realistic synthetic training data
│   ├── features/
│   │   └── feature_engineering.py# wind/gust/icing/crosswind feature pipeline
│   ├── models/
│   │   ├── baseline_model.py     # RandomForest / GradientBoosting classifier
│   │   ├── lstm_model.py         # PyTorch LSTM sequence model
│   │   └── attention_model.py    # PyTorch LSTM + self-attention model
│   ├── train.py                  # CLI: train & compare all three models
│   ├── evaluate.py               # metrics, confusion matrix, model comparison table
│   ├── predict.py                # CLI: single-point or batch risk scoring
│   └── api/app.py                # FastAPI service exposing /predict
├── tests/test_features.py
├── Dockerfile
├── requirements.txt
└── LICENSE
```

## Quickstart

A small sample dataset (`data/raw/sample_metar.csv`, 3 stations / 30 days) is
committed so you can try the pipeline immediately. For real training, generate
a larger synthetic set or pull live data (see below) — class balance (HIGH /
NO_FLY events are rare, as in real aviation weather) only emerges with enough
days of history.

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# 1. Generate a synthetic training set (no API key needed, works offline)
#    25 stations x 400 days gives a realistic class balance (~240k rows,
#    with rare HIGH/NO_FLY events) — tune down for a quick smoke test.
python -m src.data.synthetic_generator --n_stations 25 --days 400 \
    --out data/raw/synthetic_metar.csv

# 2. Build the feature table
python -m src.features.feature_engineering \
    --in data/raw/synthetic_metar.csv --out data/processed/features.parquet

# 3. Train and compare models (baseline vs LSTM vs LSTM+attention)
#    `--model baseline` needs only scikit-learn; `lstm`/`attention`/`all`
#    additionally need torch (in requirements.txt).
python -m src.train --data data/processed/features.parquet --model all

# 4. Score a single flight window
python -m src.predict --station KJFK --altitude_ft 400 \
    --wind_kt 18 --gust_kt 29 --temp_c 2 --dewpoint_c 1 \
    --visibility_sm 3 --ceiling_ft 800 --precip rain

# 5. Run as a live API
uvicorn src.api.app:app --reload --port 8000
# POST http://localhost:8000/predict  with the same fields as above
```

## Using real aviation weather data

`src/data/fetch_metar.py` pulls live/historical METAR and TAF text reports from
the **NOAA Aviation Weather Center Text Data Server**
(`https://aviationweather.gov/api/data/metar`), which is public and does not
require an API key. Example:

```bash
python -m src.data.fetch_metar --stations KJFK,KLAX,KORD --hours 72 \
    --out data/raw/live_metar.csv
```

Run that machine's network/firewall needs to allow outbound HTTPS to
`aviationweather.gov`. Swap `synthetic_metar.csv` for `live_metar.csv` in the
feature-engineering step above to train on real observations. For icing
severity and PIREP-based turbulence reports, the same text data server
exposes `/api/data/pirep` and `/api/data/airsigmet` endpoints — the fetch
script has stubs for both (`--include-pireps`, `--include-sigmets`).

## Risk features used

| Feature | Why it matters for UAVs |
|---|---|
| Sustained wind speed | Small UAVs typically have a certified max wind limit (often 20–25 kt) |
| Gust factor (gust − sustained) | Gust spread predicts loss-of-control risk better than sustained wind alone |
| Crosswind component | Computed from wind direction vs. assumed flight heading |
| Temp/dewpoint spread | Near-zero spread near/below freezing is a standard icing proxy |
| Visibility | UAV visual-line-of-sight and sense-and-avoid depend on it |
| Ceiling | Low ceiling forces lower, more turbulent flight altitudes |
| Precipitation type | Freezing rain/snow materially raise icing and motor-ingress risk |

## Model comparison (mirrors the baseline → sequence → attention pattern)

| Model | Captures | Use case |
|---|---|---|
| `baseline_model.py` | Single-timestep tabular signal | Fast, interpretable, good pre-flight check |
| `lstm_model.py` | Trend over the last N hourly observations | Deteriorating-weather detection |
| `attention_model.py` | Trend + which past hour mattered most | Best accuracy, explainable via attention weights |

`src/evaluate.py` prints an accuracy/F1/ROC-AUC comparison table across all
three after training, matching the format used in the CardioFuse project.

## Important limitations — read before any real-world use

This is a **decision-support research prototype**, not a certified aviation
safety system:

- It is **not** DO-178C / DO-200B qualified and must not be the sole basis for
  a real flight go/no-go decision.
- Synthetic training data approximates real weather statistics but is not a
  substitute for a large real METAR/TAF/PIREP corpus for your specific
  operating region.
- Icing and turbulence are proxied from surface observations; true in-flight
  icing/turbulence depends on altitude-resolved data (PIREPs, SIGMETs,
  NWP model output) that this repo only stubs.
- Always keep a human-in-the-loop and defer to official NOTAMs, TFRs, and
  aviation authority guidance (FAA/EASA/CAA) for actual operations.

## License

MIT — see `LICENSE`.
