"""
Turns raw METAR-style rows into a model-ready feature table, and derives the
ground-truth risk label used for supervised training from UAV operating
limits defined in config/config.yaml.

Usage:
    python -m src.features.feature_engineering \
        --in data/raw/synthetic_metar.csv --out data/processed/features.parquet
"""
import argparse
import yaml
import numpy as np
import pandas as pd


def load_config(path: str = "config/config.yaml") -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)


def crosswind_component(wind_dir_deg: pd.Series, wind_speed_kt: pd.Series,
                         runway_heading_deg: float = 0.0) -> pd.Series:
    """
    Crosswind magnitude relative to an assumed flight heading.
    runway_heading_deg=0 is a conservative worst-case default (headwind-aligned
    assumption removed); pass the real mission heading when known.
    """
    angle = np.radians(wind_dir_deg - runway_heading_deg)
    return (wind_speed_kt * np.sin(angle)).abs()


def icing_proxy(temp_c: pd.Series, dewpoint_c: pd.Series, freezing_thresh: float,
                 spread_thresh: float) -> pd.Series:
    spread = (temp_c - dewpoint_c).abs()
    return ((temp_c <= freezing_thresh) & (spread <= spread_thresh)).astype(int)


def build_features(df: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    df = df.copy()
    df["timestamp_utc"] = pd.to_datetime(df["timestamp_utc"], utc=True)

    limits = cfg["uav_limits"]

    df["gust_factor_kt"] = (df["gust_kt"] - df["wind_speed_kt"]).clip(lower=0)
    df["crosswind_kt"] = crosswind_component(df["wind_dir_deg"], df["wind_speed_kt"])
    df["temp_dewpoint_spread_c"] = (df["temp_c"] - df["dewpoint_c"]).abs()
    df["icing_flag"] = icing_proxy(
        df["temp_c"], df["dewpoint_c"],
        limits["freezing_temp_c"], limits["icing_spread_threshold_c"],
    )
    df["precip_severity"] = df["precip_type"].map({
        "none": 0, "rain": 1, "snow": 2, "freezing_rain": 3, "thunderstorm": 3,
    }).fillna(1).astype(int)

    df["low_visibility_flag"] = (df["visibility_sm"] < limits["min_visibility_sm"]).astype(int)
    df["low_ceiling_flag"] = (df["ceiling_ft"] < limits["min_ceiling_ft"]).astype(int)
    df["wind_exceed_flag"] = (df["wind_speed_kt"] > limits["max_sustained_wind_kt"]).astype(int)
    df["gust_exceed_flag"] = (df["gust_kt"] > limits["max_gust_kt"]).astype(int)
    df["crosswind_exceed_flag"] = (df["crosswind_kt"] > limits["max_crosswind_kt"]).astype(int)

    df["risk_score"] = compute_risk_score(df, limits)
    df["risk_category"] = categorize_risk(df["risk_score"], cfg["risk_bands"])

    df["hour"] = df["timestamp_utc"].dt.hour
    df["day_of_year"] = df["timestamp_utc"].dt.dayofyear

    return df


def compute_risk_score(df: pd.DataFrame, limits: dict) -> pd.Series:
    """
    Weighted 0-100 composite risk score. Each component is normalized against
    its UAV operating limit, so a value of 1.0 means "at the certified limit".
    This score is also the regression target; a thresholded version becomes
    the classification label used by the models.
    """
    wind_component = (df["wind_speed_kt"] / limits["max_sustained_wind_kt"]).clip(0, 2)
    gust_component = (df["gust_kt"] / limits["max_gust_kt"]).clip(0, 2)
    crosswind_component_ = (df["crosswind_kt"] / limits["max_crosswind_kt"]).clip(0, 2)
    vis_component = (limits["min_visibility_sm"] / df["visibility_sm"].clip(lower=0.1)).clip(0, 3)
    ceiling_component = (limits["min_ceiling_ft"] / df["ceiling_ft"].clip(lower=50)).clip(0, 3)
    icing_component = df["icing_flag"] * 1.5
    precip_component = df["precip_severity"] / 3.0

    raw = (
        0.22 * wind_component +
        0.20 * gust_component +
        0.15 * crosswind_component_ +
        0.15 * vis_component +
        0.10 * ceiling_component +
        0.10 * icing_component +
        0.08 * precip_component
    )
    # Fixed denominator (not batch-max) so scores stay comparable across runs
    # and datasets. max possible raw given the component clips above is
    # ~2.12 (all components simultaneously at their clip ceiling); we scale
    # so that near-worst-case conditions land close to 100.
    score = (raw * 45).clip(0, 100)
    return score.round(1)


def categorize_risk(score: pd.Series, bands: dict) -> pd.Series:
    return pd.cut(
        score,
        bins=[-0.1, bands["low_max"], bands["moderate_max"], bands["high_max"], 100.1],
        labels=["LOW", "MODERATE", "HIGH", "NO_FLY"],
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", type=str, required=True)
    ap.add_argument("--out", type=str, required=True)
    ap.add_argument("--config", type=str, default="config/config.yaml")
    args = ap.parse_args()

    cfg = load_config(args.config)
    raw = pd.read_csv(args.inp)
    feats = build_features(raw, cfg)
    feats.to_parquet(args.out, index=False)

    print(f"Built {len(feats):,} feature rows -> {args.out}")
    print(feats["risk_category"].value_counts())


if __name__ == "__main__":
    main()
