"""
Generates realistic synthetic hourly METAR-style observations for a set of
stations over N days, with embedded "extreme weather events" (storm fronts,
icing episodes, low-visibility fog banks) so the downstream models have
genuine signal to learn from.

This exists so the repo is runnable end-to-end with zero API keys. Swap in
fetch_metar.py output for production training.

Usage:
    python -m src.data.synthetic_generator --n_stations 25 --days 400 \
        --out data/raw/synthetic_metar.csv
"""
import argparse
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

STATION_IDS = [
    "KJFK", "KLAX", "KORD", "KATL", "KDFW", "KDEN", "KSEA", "KMIA",
    "KBOS", "KIAH", "KPHX", "KMSP", "KDTW", "KPHL", "KLGA", "KSFO",
    "KCLT", "KEWR", "KSLC", "KSAN", "KBWI", "KMDW", "KTPA", "KPDX", "KSTL",
]


def _simulate_station(station_id: str, n_hours: int, rng: np.random.Generator) -> pd.DataFrame:
    """Simulate one station's hourly weather with occasional storm fronts."""
    t0 = datetime(2024, 1, 1)
    timestamps = [t0 + timedelta(hours=h) for h in range(n_hours)]

    # Base diurnal + seasonal wind pattern
    hour_of_day = np.array([ts.hour for ts in timestamps])
    day_of_year = np.array([ts.timetuple().tm_yday for ts in timestamps])

    base_wind = 6 + 3 * np.sin(2 * np.pi * hour_of_day / 24) \
                  + 2 * np.sin(2 * np.pi * day_of_year / 365)
    wind_noise = rng.normal(0, 2.0, n_hours)
    wind_kt = np.clip(base_wind + wind_noise, 0, None)

    base_temp = 15 + 10 * np.sin(2 * np.pi * (day_of_year - 80) / 365) \
                    + 3 * np.sin(2 * np.pi * hour_of_day / 24)
    temp_c = base_temp + rng.normal(0, 2.0, n_hours)
    dewpoint_c = temp_c - np.abs(rng.normal(4, 3.0, n_hours))

    visibility_sm = np.clip(10 - np.abs(rng.normal(0, 1.5, n_hours)), 0.1, 10)
    ceiling_ft = np.clip(rng.normal(8000, 3000, n_hours), 100, 25000)
    gust_kt = wind_kt + np.clip(rng.exponential(2.0, n_hours), 0, 40)
    precip = np.array(["none"] * n_hours, dtype=object)

    wind_dir_deg = rng.integers(0, 360, n_hours)

    # --- Inject extreme weather events: storm fronts, icing, fog ---
    n_events = max(1, n_hours // (24 * 10))  # roughly one event every ~10 days
    for _ in range(n_events):
        start = rng.integers(0, max(1, n_hours - 24))
        duration = rng.integers(3, 18)
        end = min(n_hours, start + duration)
        event_type = rng.choice(["storm", "icing", "fog", "severe_storm"])

        if event_type == "storm":
            wind_kt[start:end] += rng.uniform(10, 20)
            gust_kt[start:end] += rng.uniform(15, 30)
            precip[start:end] = "rain"
            visibility_sm[start:end] = np.clip(visibility_sm[start:end] - rng.uniform(3, 6), 0.25, 10)
            ceiling_ft[start:end] = np.clip(ceiling_ft[start:end] - rng.uniform(3000, 6000), 100, 25000)

        elif event_type == "severe_storm":
            wind_kt[start:end] += rng.uniform(20, 35)
            gust_kt[start:end] += rng.uniform(30, 50)
            precip[start:end] = rng.choice(["rain", "thunderstorm"])
            visibility_sm[start:end] = np.clip(visibility_sm[start:end] - rng.uniform(5, 9), 0.1, 10)
            ceiling_ft[start:end] = np.clip(ceiling_ft[start:end] - rng.uniform(5000, 7500), 100, 25000)

        elif event_type == "icing":
            temp_c[start:end] = rng.uniform(-5, 2, end - start)
            dewpoint_c[start:end] = temp_c[start:end] - rng.uniform(0.2, 2.0, end - start)
            precip[start:end] = rng.choice(["snow", "freezing_rain"])
            wind_kt[start:end] += rng.uniform(3, 10)

        elif event_type == "fog":
            visibility_sm[start:end] = rng.uniform(0.1, 1.5, end - start)
            ceiling_ft[start:end] = rng.uniform(100, 600, end - start)
            dewpoint_c[start:end] = temp_c[start:end] - rng.uniform(0, 0.5, end - start)

    df = pd.DataFrame({
        "station_id": station_id,
        "timestamp_utc": timestamps,
        "wind_dir_deg": wind_dir_deg,
        "wind_speed_kt": np.round(wind_kt, 1),
        "gust_kt": np.round(gust_kt, 1),
        "temp_c": np.round(temp_c, 1),
        "dewpoint_c": np.round(dewpoint_c, 1),
        "visibility_sm": np.round(visibility_sm, 2),
        "ceiling_ft": np.round(ceiling_ft, 0),
        "precip_type": precip,
    })
    return df


def generate(n_stations: int, days: int, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    n_hours = days * 24
    stations = STATION_IDS[:n_stations] if n_stations <= len(STATION_IDS) else (
        STATION_IDS + [f"SYN{i:03d}" for i in range(n_stations - len(STATION_IDS))]
    )
    frames = [_simulate_station(sid, n_hours, rng) for sid in stations]
    out = pd.concat(frames, ignore_index=True)
    out = out.sort_values(["station_id", "timestamp_utc"]).reset_index(drop=True)
    return out


def main():
    ap = argparse.ArgumentParser(description="Generate synthetic METAR-style training data.")
    ap.add_argument("--n_stations", type=int, default=25)
    ap.add_argument("--days", type=int, default=400)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", type=str, default="data/raw/synthetic_metar.csv")
    args = ap.parse_args()

    df = generate(args.n_stations, args.days, args.seed)
    df.to_csv(args.out, index=False)
    print(f"Wrote {len(df):,} rows across {df['station_id'].nunique()} stations -> {args.out}")


if __name__ == "__main__":
    main()
