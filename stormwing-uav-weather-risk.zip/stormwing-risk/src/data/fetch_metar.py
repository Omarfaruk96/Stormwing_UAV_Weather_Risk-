"""
Pulls live/historical METAR observations from the NOAA Aviation Weather
Center public Text Data Server (no API key required):

    https://aviationweather.gov/api/data/metar

Docs: https://aviationweather.gov/data/api/

Usage:
    python -m src.data.fetch_metar --stations KJFK,KLAX,KORD --hours 72 \
        --out data/raw/live_metar.csv

Optional extras (stubs you can extend):
    --include-pireps    also pulls PIREP turbulence/icing reports
    --include-sigmets   also pulls active AIRMET/SIGMET polygons
"""
import argparse
import sys
import pandas as pd
import requests

BASE_URL = "https://aviationweather.gov/api/data"


def fetch_metar(stations: list[str], hours: int) -> pd.DataFrame:
    params = {
        "ids": ",".join(stations),
        "format": "json",
        "hours": hours,
        "taf": "false",
    }
    resp = requests.get(f"{BASE_URL}/metar", params=params, timeout=30)
    resp.raise_for_status()
    records = resp.json()
    if not records:
        return pd.DataFrame()

    rows = []
    for r in records:
        rows.append({
            "station_id": r.get("icaoId"),
            "timestamp_utc": r.get("reportTime"),
            "wind_dir_deg": r.get("wdir"),
            "wind_speed_kt": r.get("wspd"),
            "gust_kt": r.get("wgst") or r.get("wspd"),
            "temp_c": r.get("temp"),
            "dewpoint_c": r.get("dewp"),
            "visibility_sm": r.get("visib"),
            "ceiling_ft": _lowest_ceiling(r.get("clouds", [])),
            "precip_type": _precip_from_wx(r.get("wxString", "")),
            "raw_metar": r.get("rawOb"),
        })
    return pd.DataFrame(rows)


def _lowest_ceiling(clouds: list) -> float:
    """Lowest BKN/OVC layer in feet, else a high default (clear/scattered)."""
    ceilings = [c["base"] for c in clouds if c.get("cover") in ("BKN", "OVC") and c.get("base") is not None]
    return min(ceilings) if ceilings else 25000.0


def _precip_from_wx(wx_string: str) -> str:
    wx = (wx_string or "").upper()
    if "FZRA" in wx or "FZ" in wx:
        return "freezing_rain"
    if "SN" in wx:
        return "snow"
    if "TS" in wx:
        return "thunderstorm"
    if "RA" in wx or "SH" in wx:
        return "rain"
    return "none"


def fetch_pireps(stations: list[str], hours: int) -> pd.DataFrame:
    """Stub: PIREP turbulence/icing reports near given stations."""
    params = {"ids": ",".join(stations), "format": "json", "age": hours}
    resp = requests.get(f"{BASE_URL}/pirep", params=params, timeout=30)
    resp.raise_for_status()
    return pd.json_normalize(resp.json())


def fetch_sigmets() -> pd.DataFrame:
    """Stub: active AIRMET/SIGMET polygons (convective, icing, turbulence)."""
    resp = requests.get(f"{BASE_URL}/airsigmet", params={"format": "json"}, timeout=30)
    resp.raise_for_status()
    return pd.json_normalize(resp.json())


def main():
    ap = argparse.ArgumentParser(description="Fetch live METAR data from aviationweather.gov")
    ap.add_argument("--stations", type=str, required=True, help="Comma-separated ICAO codes, e.g. KJFK,KLAX")
    ap.add_argument("--hours", type=int, default=72, help="Lookback window in hours")
    ap.add_argument("--out", type=str, default="data/raw/live_metar.csv")
    ap.add_argument("--include-pireps", action="store_true")
    ap.add_argument("--include-sigmets", action="store_true")
    args = ap.parse_args()

    stations = [s.strip().upper() for s in args.stations.split(",")]

    try:
        df = fetch_metar(stations, args.hours)
    except requests.RequestException as e:
        print(f"ERROR fetching METAR data: {e}", file=sys.stderr)
        print("Check that this machine allows outbound HTTPS to aviationweather.gov", file=sys.stderr)
        sys.exit(1)

    if df.empty:
        print("No METAR records returned for the given stations/window.", file=sys.stderr)
        sys.exit(1)

    df.to_csv(args.out, index=False)
    print(f"Wrote {len(df):,} METAR rows -> {args.out}")

    if args.include_pireps:
        pireps = fetch_pireps(stations, args.hours)
        pireps_out = args.out.replace(".csv", "_pireps.csv")
        pireps.to_csv(pireps_out, index=False)
        print(f"Wrote {len(pireps):,} PIREP rows -> {pireps_out}")

    if args.include_sigmets:
        sigmets = fetch_sigmets()
        sigmets_out = args.out.replace(".csv", "_sigmets.csv")
        sigmets.to_csv(sigmets_out, index=False)
        print(f"Wrote {len(sigmets):,} AIRMET/SIGMET rows -> {sigmets_out}")


if __name__ == "__main__":
    main()
