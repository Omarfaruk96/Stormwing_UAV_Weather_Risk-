"""
Trains the baseline, LSTM, and LSTM+attention models on the processed
feature table and saves artifacts to models_artifacts/.

Usage:
    python -m src.train --data data/processed/features.parquet --model all
    python -m src.train --data data/processed/features.parquet --model baseline
"""
import argparse
import os
import pandas as pd
import yaml

from src.models.baseline_model import BaselineRiskModel
from src.evaluate import evaluate_predictions
# torch / sequence-model imports are deferred into their branches below so
# `--model baseline` works without torch installed at all.


def load_config(path: str = "config/config.yaml") -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)


def time_split(df: pd.DataFrame, train_frac: float = 0.8):
    df = df.sort_values("timestamp_utc")
    cutoff = df["timestamp_utc"].quantile(train_frac)
    return df[df["timestamp_utc"] <= cutoff], df[df["timestamp_utc"] > cutoff]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=str, required=True)
    ap.add_argument("--model", type=str, default="all", choices=["baseline", "lstm", "attention", "all"])
    ap.add_argument("--config", type=str, default="config/config.yaml")
    ap.add_argument("--out_dir", type=str, default="models_artifacts")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    cfg = load_config(args.config)
    df = pd.read_parquet(args.data)
    df["timestamp_utc"] = pd.to_datetime(df["timestamp_utc"])

    train_df, test_df = time_split(df)
    print(f"Train rows: {len(train_df):,}  Test rows: {len(test_df):,}")

    results = {}

    if args.model in ("baseline", "all"):
        print("\n=== Training baseline RandomForest ===")
        bm = BaselineRiskModel().fit(train_df)
        bm.save(os.path.join(args.out_dir, "baseline_model.joblib"))
        preds = bm.predict(test_df)
        results["baseline"] = evaluate_predictions(test_df["risk_category"].astype(str), preds, "Baseline (RandomForest)")
        print("Top features:\n", bm.feature_importances().head(8))

    lookback = cfg["sequence_model"]["lookback_hours"]

    if args.model in ("lstm", "all"):
        print("\n=== Training LSTM ===")
        import torch
        from src.models.lstm_model import SequenceDataset, train_lstm, predict_lstm
        train_ds = SequenceDataset(train_df, lookback)
        test_ds = SequenceDataset(pd.concat([train_df.tail(lookback), test_df]), lookback)
        model = train_lstm(train_ds, cfg)
        torch.save(model.state_dict(), os.path.join(args.out_dir, "lstm_model.pt"))
        preds = predict_lstm(model, test_ds)
        labels = list(test_df["risk_category"].astype(str).values[:len(preds)])
        results["lstm"] = evaluate_predictions(pd.Series(labels), preds, "LSTM")

    if args.model in ("attention", "all"):
        print("\n=== Training LSTM + Attention ===")
        import torch
        from src.models.lstm_model import SequenceDataset
        from src.models.attention_model import train_attention_model, predict_attention
        train_ds = SequenceDataset(train_df, lookback)
        test_ds = SequenceDataset(pd.concat([train_df.tail(lookback), test_df]), lookback)
        model = train_attention_model(train_ds, cfg)
        torch.save(model.state_dict(), os.path.join(args.out_dir, "attention_model.pt"))
        preds = predict_attention(model, test_ds)
        labels = list(test_df["risk_category"].astype(str).values[:len(preds)])
        results["attention"] = evaluate_predictions(pd.Series(labels), preds, "LSTM + Attention")

    if len(results) > 1:
        print("\n=== Model comparison ===")
        comp = pd.DataFrame(results).T[["accuracy", "f1_macro"]]
        print(comp.round(4))
        comp.to_csv(os.path.join(args.out_dir, "model_comparison.csv"))


if __name__ == "__main__":
    main()
