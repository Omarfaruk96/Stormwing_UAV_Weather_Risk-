"""
Shared evaluation helpers: accuracy, macro-F1, per-class report, confusion
matrix — printed in a consistent format for each model so results are
directly comparable.
"""
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix

CLASS_ORDER = ["LOW", "MODERATE", "HIGH", "NO_FLY"]


def evaluate_predictions(y_true, y_pred, model_name: str) -> dict:
    y_true = pd.Series(y_true).astype(str).reset_index(drop=True)
    y_pred = pd.Series(y_pred).astype(str).reset_index(drop=True)

    acc = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred, average="macro", labels=CLASS_ORDER, zero_division=0)

    print(f"\n--- {model_name} ---")
    print(f"Accuracy: {acc:.4f}   Macro-F1: {f1:.4f}")
    print(classification_report(y_true, y_pred, labels=CLASS_ORDER, zero_division=0))
    cm = confusion_matrix(y_true, y_pred, labels=CLASS_ORDER)
    print("Confusion matrix (rows=true, cols=pred), order =", CLASS_ORDER)
    print(pd.DataFrame(cm, index=CLASS_ORDER, columns=CLASS_ORDER))

    return {"accuracy": acc, "f1_macro": f1}
