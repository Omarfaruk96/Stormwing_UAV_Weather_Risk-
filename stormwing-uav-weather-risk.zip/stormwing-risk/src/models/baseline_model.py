"""
Baseline single-timestep risk classifier: RandomForest over the engineered
tabular features. Fast to train, easy to explain (feature importances),
and a fair floor to beat with the sequence models.
"""
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder

FEATURE_COLS = [
    "wind_speed_kt", "gust_kt", "gust_factor_kt", "crosswind_kt",
    "temp_c", "dewpoint_c", "temp_dewpoint_spread_c", "icing_flag",
    "precip_severity", "visibility_sm", "ceiling_ft",
    "low_visibility_flag", "low_ceiling_flag", "wind_exceed_flag",
    "gust_exceed_flag", "crosswind_exceed_flag", "hour",
]


class BaselineRiskModel:
    def __init__(self, n_estimators: int = 300, max_depth: int = 12, random_state: int = 42):
        self.clf = RandomForestClassifier(
            n_estimators=n_estimators, max_depth=max_depth,
            random_state=random_state, class_weight="balanced", n_jobs=-1,
        )
        self.label_encoder = LabelEncoder()

    def fit(self, df: pd.DataFrame):
        X = df[FEATURE_COLS].values
        y = self.label_encoder.fit_transform(df["risk_category"].astype(str))
        self.clf.fit(X, y)
        return self

    def predict(self, df: pd.DataFrame) -> np.ndarray:
        X = df[FEATURE_COLS].values
        preds = self.clf.predict(X)
        return self.label_encoder.inverse_transform(preds)

    def predict_proba(self, df: pd.DataFrame) -> np.ndarray:
        return self.clf.predict_proba(df[FEATURE_COLS].values)

    def feature_importances(self) -> pd.Series:
        return pd.Series(self.clf.feature_importances_, index=FEATURE_COLS).sort_values(ascending=False)

    def save(self, path: str):
        joblib.dump({"clf": self.clf, "label_encoder": self.label_encoder}, path)

    @classmethod
    def load(cls, path: str) -> "BaselineRiskModel":
        obj = cls()
        data = joblib.load(path)
        obj.clf = data["clf"]
        obj.label_encoder = data["label_encoder"]
        return obj
