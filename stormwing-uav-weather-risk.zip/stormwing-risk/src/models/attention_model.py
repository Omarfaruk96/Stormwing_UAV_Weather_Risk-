"""
LSTM + multi-head self-attention over the lookback window. Lets the model
learn *which* past hour in the window mattered most for the current risk
call (e.g. "the gust spike 3 hours ago" vs "the steady crosswind all
window") and exposes those attention weights for explainability — useful
when a human operator needs to know *why* the system flagged NO-FLY.
"""
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from src.models.lstm_model import SequenceDataset, CLASS_ORDER
from src.models.baseline_model import FEATURE_COLS

N_CLASSES = len(CLASS_ORDER)


class LSTMAttentionRiskModel(nn.Module):
    def __init__(self, n_features: int = len(FEATURE_COLS), hidden_size: int = 32,
                 num_layers: int = 1, n_heads: int = 2, n_classes: int = N_CLASSES):
        super().__init__()
        self.lstm = nn.LSTM(n_features, hidden_size, num_layers, batch_first=True)
        self.attn = nn.MultiheadAttention(embed_dim=hidden_size, num_heads=n_heads, batch_first=True)
        self.norm = nn.LayerNorm(hidden_size)
        self.head = nn.Linear(hidden_size, n_classes)
        self._last_attn_weights = None

    def forward(self, x, return_attention: bool = False):
        seq_out, _ = self.lstm(x)                      # (batch, seq_len, hidden)
        attn_out, attn_weights = self.attn(seq_out, seq_out, seq_out)
        self._last_attn_weights = attn_weights.detach()
        fused = self.norm(seq_out + attn_out)
        pooled = fused.mean(dim=1)                      # mean pool over time
        logits = self.head(pooled)
        if return_attention:
            return logits, attn_weights
        return logits

    def last_attention_weights(self):
        """(batch, seq_len, seq_len) attention map from the most recent forward pass."""
        return self._last_attn_weights


def train_attention_model(dataset: SequenceDataset, cfg: dict, device: str = "cpu") -> LSTMAttentionRiskModel:
    seq_cfg = cfg["sequence_model"]
    model = LSTMAttentionRiskModel(
        hidden_size=seq_cfg["hidden_size"], num_layers=seq_cfg["num_layers"],
        n_heads=seq_cfg["attention_heads"],
    ).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=seq_cfg["learning_rate"])
    loss_fn = nn.CrossEntropyLoss()
    loader = DataLoader(dataset, batch_size=seq_cfg["batch_size"], shuffle=True)

    model.train()
    for epoch in range(seq_cfg["epochs"]):
        total_loss = 0.0
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            opt.zero_grad()
            logits = model(xb)
            loss = loss_fn(logits, yb)
            loss.backward()
            opt.step()
            total_loss += loss.item() * xb.size(0)
        if (epoch + 1) % 5 == 0 or epoch == 0:
            print(f"  [LSTM+Attn] epoch {epoch + 1}/{seq_cfg['epochs']}  loss={total_loss / len(dataset):.4f}")
    return model


@torch.no_grad()
def predict_attention(model: LSTMAttentionRiskModel, dataset: SequenceDataset, device: str = "cpu") -> np.ndarray:
    model.eval()
    loader = DataLoader(dataset, batch_size=256, shuffle=False)
    preds = []
    for xb, _ in loader:
        logits = model(xb.to(device))
        preds.extend(logits.argmax(dim=1).cpu().numpy().tolist())
    return np.array([CLASS_ORDER[p] for p in preds])
