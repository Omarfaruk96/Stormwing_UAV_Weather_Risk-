"""
LSTM sequence model: looks back `lookback_hours` observations at a station
to catch a *deteriorating* weather trend (e.g. gust rising hour over hour)
that a single-timestep model can't see.
"""
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

from src.models.baseline_model import FEATURE_COLS

N_CLASSES = 4  # LOW, MODERATE, HIGH, NO_FLY
CLASS_ORDER = ["LOW", "MODERATE", "HIGH", "NO_FLY"]


class SequenceDataset(Dataset):
    """Builds sliding windows of `lookback` hourly observations per station."""

    def __init__(self, df: pd.DataFrame, lookback: int):
        self.lookback = lookback
        self.samples = []
        self.labels = []
        df = df.sort_values(["station_id", "timestamp_utc"])
        for _, g in df.groupby("station_id"):
            feats = g[FEATURE_COLS].values.astype(np.float32)
            labels = g["risk_category"].astype(str).values
            for i in range(lookback, len(g)):
                window = feats[i - lookback:i]
                label = CLASS_ORDER.index(labels[i])
                self.samples.append(window)
                self.labels.append(label)

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        return torch.tensor(self.samples[idx]), torch.tensor(self.labels[idx], dtype=torch.long)


class LSTMRiskModel(nn.Module):
    def __init__(self, n_features: int = len(FEATURE_COLS), hidden_size: int = 32,
                 num_layers: int = 1, n_classes: int = N_CLASSES):
        super().__init__()
        self.lstm = nn.LSTM(n_features, hidden_size, num_layers, batch_first=True)
        self.head = nn.Linear(hidden_size, n_classes)

    def forward(self, x):
        out, (h_n, _) = self.lstm(x)
        last_hidden = h_n[-1]
        return self.head(last_hidden)


def train_lstm(dataset: SequenceDataset, cfg: dict, device: str = "cpu") -> LSTMRiskModel:
    seq_cfg = cfg["sequence_model"]
    model = LSTMRiskModel(
        hidden_size=seq_cfg["hidden_size"], num_layers=seq_cfg["num_layers"],
    ).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=seq_cfg["learning_rate"])
    loss_fn = nn.CrossEntropyLoss()
    loader = DataLoader(dataset, batch_size=seq_cfg["batch_size"], shuffle=True)

    model.train()
    for epoch in range(seq_cfg["epochs"]):
        total_loss = 0.0
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            opt.zero_grad()
            logits = model(xb)
            loss = loss_fn(logits, yb)
            loss.backward()
            opt.step()
            total_loss += loss.item() * xb.size(0)
        if (epoch + 1) % 5 == 0 or epoch == 0:
            print(f"  [LSTM] epoch {epoch + 1}/{seq_cfg['epochs']}  loss={total_loss / len(dataset):.4f}")
    return model


@torch.no_grad()
def predict_lstm(model: LSTMRiskModel, dataset: SequenceDataset, device: str = "cpu") -> np.ndarray:
    model.eval()
    loader = DataLoader(dataset, batch_size=256, shuffle=False)
    preds = []
    for xb, _ in loader:
        logits = model(xb.to(device))
        preds.extend(logits.argmax(dim=1).cpu().numpy().tolist())
    return np.array([CLASS_ORDER[p] for p in preds])
