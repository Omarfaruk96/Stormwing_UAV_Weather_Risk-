"""
FastAPI service exposing the risk model as a live HTTP endpoint, so it can
be called directly from a ground-control station or mission-planning
pipeline.

Run:
    uvicorn src.api.app:app --reload --port 8000

Then:
    POST http://localhost:8000/predict
    {
      "station": "KJFK", "altitude_ft": 400, "wind_dir_deg": 270,
      "wind_kt": 18, "gust_kt": 29, "temp_c": 2, "dewpoint_c": 1,
      "visibility_sm": 3, "ceiling_ft": 800, "precip": "rain"
    }
"""
from fastapi import FastAPI
from pydantic import BaseModel, Field

from src.predict import load_config, score_single

app = FastAPI(
    title="StormWing UAV Flight-Risk API",
    description="Predicts a flight risk score/category from aviation weather inputs. "
                 "Research prototype — not a certified aviation safety system.",
    version="0.1.0",
)

CFG = load_config()


class FlightWindowRequest(BaseModel):
    station: str = Field(..., example="KJFK")
    altitude_ft: float = Field(400, example=400)
    wind_dir_deg: float = Field(0, example=270)
    wind_kt: float = Field(..., example=18)
    gust_kt: float = Field(..., example=29)
    temp_c: float = Field(..., example=2)
    dewpoint_c: float = Field(..., example=1)
    visibility_sm: float = Field(..., example=3)
    ceiling_ft: float = Field(..., example=800)
    precip: str = Field("none", example="rain")


class _Args:
    """Lightweight shim so score_single (built for argparse.Namespace) works here too."""
    def __init__(self, req: FlightWindowRequest):
        self.__dict__.update(req.dict())


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/predict")
def predict(req: FlightWindowRequest):
    args = _Args(req)
    result = score_single(args, CFG)
    return result
