"""
Score a single flight window from the command line using the trained
baseline model (fastest path to a go/no-go number; swap in the LSTM/
attention model if you have enough recent hourly history for that station).

Usage:
    python -m src.predict --station KJFK --altitude_ft 400 \
        --wind_kt 18 --gust_kt 29 --temp_c 2 --dewpoint_c 1 \
        --visibility_sm 3 --ceiling_ft 800 --precip rain
"""
import argparse
import pandas as pd
import yaml

from src.features.feature_engineering import build_features
from src.models.baseline_model import BaselineRiskModel


def load_config(path: str = "config/config.yaml") -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)


def score_single(args, cfg) -> dict:
    row = pd.DataFrame([{
        "station_id": args.station,
        "timestamp_utc": pd.Timestamp.now("UTC"),
        "wind_dir_deg": args.wind_dir_deg,
        "wind_speed_kt": args.wind_kt,
        "gust_kt": args.gust_kt,
        "temp_c": args.temp_c,
        "dewpoint_c": args.dewpoint_c,
        "visibility_sm": args.visibility_sm,
        "ceiling_ft": args.ceiling_ft,
        "precip_type": args.precip,
    }])
    feats = build_features(row, cfg)

    model_path = "models_artifacts/baseline_model.joblib"
    try:
        model = BaselineRiskModel.load(model_path)
        ml_category = model.predict(feats)[0]
        ml_proba = dict(zip(model.label_encoder.classes_, model.predict_proba(feats)[0].round(3)))
    except FileNotFoundError:
        ml_category, ml_proba = None, None

    return {
        "station": args.station,
        "altitude_ft": args.altitude_ft,
        "rule_based_risk_score": float(feats["risk_score"].iloc[0]),
        "rule_based_category": str(feats["risk_category"].iloc[0]),
        "ml_category": ml_category,
        "ml_class_probabilities": ml_proba,
        "flags": {
            "icing_risk": bool(feats["icing_flag"].iloc[0]),
            "low_visibility": bool(feats["low_visibility_flag"].iloc[0]),
            "low_ceiling": bool(feats["low_ceiling_flag"].iloc[0]),
            "wind_exceeds_limit": bool(feats["wind_exceed_flag"].iloc[0]),
            "gust_exceeds_limit": bool(feats["gust_exceed_flag"].iloc[0]),
            "crosswind_exceeds_limit": bool(feats["crosswind_exceed_flag"].iloc[0]),
        },
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--station", type=str, required=True)
    ap.add_argument("--altitude_ft", type=float, default=400)
    ap.add_argument("--wind_dir_deg", type=float, default=0)
    ap.add_argument("--wind_kt", type=float, required=True)
    ap.add_argument("--gust_kt", type=float, required=True)
    ap.add_argument("--temp_c", type=float, required=True)
    ap.add_argument("--dewpoint_c", type=float, required=True)
    ap.add_argument("--visibility_sm", type=float, required=True)
    ap.add_argument("--ceiling_ft", type=float, required=True)
    ap.add_argument("--precip", type=str, default="none",
                     choices=["none", "rain", "snow", "freezing_rain", "thunderstorm"])
    ap.add_argument("--config", type=str, default="config/config.yaml")
    args = ap.parse_args()

    cfg = load_config(args.config)
    result = score_single(args, cfg)

    print("\n=== StormWing Flight Risk Assessment ===")
    for k, v in result.items():
        print(f"{k}: {v}")


if __name__ == "__main__":
    main()
